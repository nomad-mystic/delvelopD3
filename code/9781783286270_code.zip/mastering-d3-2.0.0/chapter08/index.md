---
layout: default
title: 8. Deploying the Visualizations
---

The `hdi-explorer` project files are available in the folder `chapter08/hdi-explorer`. Please run `bower install` in the `hdi-explorer` directory to download and install the project dependencies.

