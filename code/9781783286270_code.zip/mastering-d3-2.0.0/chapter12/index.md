---
layout: default
title: 12. Social Media and Collaboration
---

<h1 class="section-title">{{ page.title }}</h1>

The examples of this chapter are available at the `hdi-explorer` repository.

